package com.kh.day7;

public class Test9 {
  public static void main(String[] args) {
    System.out.println("hello");
    String name = "홍길동";

//     Arrays.sort(new int[]{1,2,3});
  }
}
