package com.kh.day7;

public class Test5 {
  public static void main(String[] args) {
    System.out.println(args.length);
    System.out.println(args);
    for (String ele : args) {
      System.out.println(ele);
    }
  }
}
