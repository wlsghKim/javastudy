package com.kh.day10.b;

public class CarMain {
  public static void main(String[] args) {
    //객체의 인스턴스화(실체화)

    //객체에 속성 주기

    //객체에 행위 요청하기

    //객체 상태 확인하기
  }
}


