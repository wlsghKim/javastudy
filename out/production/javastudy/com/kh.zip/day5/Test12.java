package com.kh.day5;

public class Test12 {
    public static void main(String[] args) {
        byte a =3;
        byte b =5;
        byte c =(byte)130;
        byte d = (byte)(a+b);
        long e = 100;
        float f= 3.5f;
    }
}