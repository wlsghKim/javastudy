package com.kh.day5;

public class Test5 {
    public static void main(String[] args) {
        int value7 = 3;
        int value8 =4;
        int value9 =2 + value7-- + ++value8;
        System.out.println(value7);
        System.out.println(value8);
        System.out.println(value9);
    }
}
