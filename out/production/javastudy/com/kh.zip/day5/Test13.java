package com.kh.day5;

public class Test13 {
    public static void main(String[] args) {
        //산술 연산자
        System.out.println((int)5.6+3.5);
        System.out.println((int)5.6 + (int)3.5);
        System.out.println((int)(5.6+3.5));
        System.out.println(7/4);
        System.out.println((double) 3/2);
        System.out.println((double)(3/2));
        System.out.println();
    }
}
