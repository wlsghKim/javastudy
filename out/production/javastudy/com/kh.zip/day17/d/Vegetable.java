package com.kh.day17.d;

public class Vegetable {

}
