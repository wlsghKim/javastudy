package com.kh.day17.d;

public class Orange extends Fruit{
}
