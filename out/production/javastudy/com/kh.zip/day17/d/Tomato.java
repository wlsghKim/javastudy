package com.kh.day17.d;

public class Tomato extends Vegetable{
}
