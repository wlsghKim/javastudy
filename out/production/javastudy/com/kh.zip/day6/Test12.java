package com.kh.day6;

public class Test12 {
    public static void main(String[] args) {
        int[] array = new int[]{1, 2, 3, 4, 5};

        // 첫번째 요소 (1행 1열)
        System.out.println(array[0]);

        //마지막 요소
        System.out.println(array[array.length-1]);

       //마지막에서 2번째 요소
        System.out.println(array[array.length-2]);
    }
}
