package com.kh.day6;

public class Test8 {
    public static void main(String[] args) {
     int x =Integer.parseInt("10");

     double y =Double.parseDouble("3.14");

     boolean flag =Boolean.parseBoolean("true");

     int a =10;
     String b = String.valueOf(a);

     double c = 3.14;
     String d = String.valueOf(c);

     boolean e =true;
     String f =String.valueOf(e);
    }
}