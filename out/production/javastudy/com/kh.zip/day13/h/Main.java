package com.kh.day13.h;

public class Main {
  public static void main(String[] args) {

    A ab = new B();
    System.out.println(ab.m);
    System.out.println(ab.n);
    ab.method1();
    ab.method2();

  }
}
