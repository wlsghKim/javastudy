package com.kh.day13.h;

public class A {
  int m = 2;
  static int n = 4;
  void method1(){
    System.out.println("A 클래스 instance method");
  }

  static void method2() {
    System.out.println("A 클래스 static method");

  }
}
