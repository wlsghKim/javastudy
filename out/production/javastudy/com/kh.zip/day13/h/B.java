package com.kh.day13.h;

public class B extends A {
  int m = 6;
  static int n = 8;

  void method1() {
    System.out.println("B클래스 instance method");
  }

  static void method2() {
    System.out.println("B클래스 static method");
  }
}
