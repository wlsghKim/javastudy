package com.kh.day13.e;

public class Person {
  String name = "홍길동";
  static int age = 20;
  public void eat(){
    System.out.println("먹다");
  }
}
