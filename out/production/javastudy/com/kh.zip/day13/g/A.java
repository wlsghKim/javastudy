package com.kh.day13.g;

public class A {
  void hello() {
    System.out.println("안녕하세요");
  }
  }

