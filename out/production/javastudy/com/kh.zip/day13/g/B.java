package com.kh.day13.g;

public class B extends A{
  @Override
  void hello() {
    System.out.println("반갑습니다");
  }
}
