package com.kh.day13.c;

public class Man4 {
  public static void main(String[] args) {
//    Student student = (Student)(new Person());

//      HighStudent highStudent = (HighStudent)(new Person());
//      HighStudent highStudent = (HighStudent)(new Teacher());

        Teacher teacher1 =(Teacher)new Person();
//        Teacher teacher2 = new Student(); //아무관계없음
//        Teacher teacher3 = new HighStudent(); //아무관계없음


  }
}
