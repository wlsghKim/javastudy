package com.kh.day13.c;

public class Teacher extends Person {
  void teach() {
    System.out.println("가르치다");
  }
}
