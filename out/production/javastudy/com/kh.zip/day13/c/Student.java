package com.kh.day13.c;

public class Student extends Person{
  void study() {
    System.out.println("공부하다");
  }
}
