package com.kh.day13.c;

public class Person {
  void eat() {
    System.out.println("먹다");

  }
}
