package com.kh.day13.c;

public class HighStudent extends Student {
  void testSat() {
    System.out.println("수능시험을 치르다");
  }
}
