package com.kh.day13.a;

public class A {
  static int a;
  //  public A(int a){
  //    A.a = a;


  //정적 초기화 ㅂㄹ럭
  //멤버 정적 필드 초기화하는 용도
  static {
//    int x = 10;
//    int y = 10;
//    a = x + y;
    a = 8;
  }
}

