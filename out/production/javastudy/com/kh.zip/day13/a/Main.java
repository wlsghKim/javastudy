package com.kh.day13.a;

public class Main {
  public static void main(String[] args) {

    System.out.println(A.a);
//    A a = new A();
//    System.out.println(A.a);
//    A b = new A();
//    System.out.println(b.a);
//    A.a = 8;
//    System.out.println(a.a);
//    System.out.println(b.a);

//    A a = new A(8);
//    System.out.println(a.a);
//    System.out.println(A.a);
  }
}
