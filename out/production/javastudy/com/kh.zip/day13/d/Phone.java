package com.kh.day13.d;

public class Phone {
  void speak() {
    System.out.println("통화하다");
  }
}
