package com.kh.day13.d;

public class SamsungPhone extends Phone{
  @Override
  void speak() {
    System.out.println("삼성폰으로 통화하다");
  }
}
