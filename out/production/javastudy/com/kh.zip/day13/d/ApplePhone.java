package com.kh.day13.d;

public class ApplePhone extends Phone {
  @Override
  void speak() {
    System.out.println("애플폰으로 통화하다");
  }
}
