package com.kh.day13.d;

public class LgPhone extends Phone{
  @Override
  void speak() {
    System.out.println("엘지폰으로 통화하다");
  }
}
