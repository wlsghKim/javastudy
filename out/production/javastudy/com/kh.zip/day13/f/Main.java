package com.kh.day13.f;

public class Main {
  public static void main(String[] args) {
//    Person person = new Person()
//    // toString() : 객체(인스턴스)의 상태정보(특정시점의 속성값)를 문자열로 반환
//    System.out.println(person.toString());
//    // hashCode() : 객체(인스턴스)의 주소값을 내부적으로 변환하여 문자열로 반환.
//    System.out.println(person.hashCode());
//    // getClass() : 객체의 클래스정보를 Class타입의 객체로 반환.
//    Class a = person.getClass();
//    System.out.println(person.getClass().toString());
//    // equals() : Object의 equals()메소드 내부는 ==
//
//
//    String name = "홍길동";
//    System.out.println(name.equals("홍길동"));

  }
}
