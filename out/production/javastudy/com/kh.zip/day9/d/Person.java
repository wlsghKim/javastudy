package com.kh.day9.d;

public class Person {
  public String name;
  public int age;
  public Tv tv;
}
