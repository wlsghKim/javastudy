package com.kh.day9.c;

public class Person {
  String name;
  int age;
  Car car;

  // 웃다
  public void smile() {
    System.out.println("웃다");
  }

  // 자다
  public void sleep() {
    System.out.println("자다");
  }
}
