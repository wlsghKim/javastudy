package com.kh.day9.c;

public class Car {
  String color;

  // 운행
  public void run(){
    System.out.println("운행하다");
  }
  public void stop(){
    System.out.println("멈추다");
  }
}
