package com.kh.day9.e;

public class Main {
  public static void main(String[] args) {
   Person p = new Person("홍길동");
    p.setAge(100);
    System.out.println(p.getAge());
  }
}
