package com.kh.day9.a;

public class Battery {
  public void method1(String msg) {
    System.out.println("method1() 호출됨");

  }
}
