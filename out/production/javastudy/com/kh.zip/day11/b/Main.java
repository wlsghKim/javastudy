package com.kh.day11.b;

public class Main {
  public static void main(String[] args) {
    HighStudent hs = new HighStudent();
    hs.method1();
  }
}
