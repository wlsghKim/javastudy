package com.kh.day11.b;

public class Student extends Person {
  public Student() {
    super();
    System.out.println("public Student() called!");
  }

  public void method1() {
    System.out.println("method1() of Student called!");
  }
}