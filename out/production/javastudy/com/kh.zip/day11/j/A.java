package com.kh.day11.j;

public class A {
  int a = 3;
  static int b = 5;

  static void method1() {
    System.out.println(b);
  }
}
