package com.kh.day11.d;

public class A {
}
