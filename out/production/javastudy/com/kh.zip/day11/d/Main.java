package com.kh.day11.d;

public class Main {
  public static void main(String[] args) {
    int[] data1 = new int[]{1, 2, 3};
    int[] data2 = {1, 2, 3};  //배열 선언, 생성, 초기화
    int[] data3;
    data3 = new int[]{1, 2, 3};

    int[] data4;
   // data4 = {1, 2, 3}; //배열 선언과 생성분리 불가
  }
}