package com.kh.day11.c;

public class Main {
  public static void main(String[] args) {
    A a = new A();
    a.print();
    a.print(3);
    a.print(5.8);
    a.print("안녕");
  }
}
