package com.kh.day11.i.pack02;

import com.kh.day11.i.pack01.A;

public class C {
  void cde() {
    A a = new A();
    System.out.println(a.a);
//    System.out.println(a.b);
//    System.out.println(a.c);
//    System.out.println(a.d);
  }
}
