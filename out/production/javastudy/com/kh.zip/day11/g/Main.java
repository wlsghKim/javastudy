package com.kh.day11.g;

public class Main {
  public static void main(String[] args) {
    A a = new A();
    a.averageScore(1);
    a.averageScore(1, 2);
    a.averageScore(1, 2, 3);
    a.averageScore(1, 2, 3, 4);
    // ...
  }
}
