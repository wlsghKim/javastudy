package com.kh.day11.h;

public class Main {
  public static void main(String[] args) {
    A a = new A();
    a.abc(7, 8);
    System.out.println(a.m);
    System.out.println(a.n);


  }
}
