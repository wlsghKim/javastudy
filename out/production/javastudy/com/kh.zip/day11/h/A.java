package com.kh.day11.h;

public class A {
  int m = 3;
  int n = 5;

  void abc(int m, int n) {
    m = this.m;
    n = n;
  }
}
