package com.kh.day16.h;

public class Main3 {
  public static void main(String[] args) {
    String str1 = "가나다";
    String str3 = "가다";

    System.out.println(str3.compareTo(str1));

    int x = 10;
    int y = 20;

    Integer x2 = x;
    Integer y2 = y;

    System.out.println(y2.compareTo(x2));

  }
}

