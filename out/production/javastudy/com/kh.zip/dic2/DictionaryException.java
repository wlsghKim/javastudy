package com.kh.dic2;

public class DictionaryException extends RuntimeException {
  public DictionaryException(String message) {
    super(message);

  }
}

