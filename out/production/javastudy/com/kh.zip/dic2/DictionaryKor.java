package com.kh.dic2;

import java.util.List;
import java.util.Map;

public class DictionaryKor implements DictionaryI{
  @Override
  public void put(String word, String meaning) {

  }

  @Override
  public Map<String, String> findByWord(String word) {
    return null;
  }

  @Override
  public void update(String word, String meaning) {

  }

  @Override
  public void delete(String word) {

  }

  @Override
  public Map<String, String> list(int howToSort) {
    return null;
  }

  @Override
  public List<String> index(char ch) {
    return null;
  }

  @Override
  public List<Object> statistics() {
    return null;
  }
}
