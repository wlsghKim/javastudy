package com.kh.day4;

public class Test1 {
    public static void main(String[] args) {
        int x = 10;

        int i;
        for (i = 0; i < 3; i++) {
            int y =5;
            System.out.println("i = " + i);
            System.out.println("x=" + 10);
            System.out.println("y=" + y);
        }

        System.out.println(x);
//        System.out.println(i);
//        System.out.println(y);

    }
}
