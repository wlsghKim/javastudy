package com.kh.dic;

public class DictionaryException {
}
