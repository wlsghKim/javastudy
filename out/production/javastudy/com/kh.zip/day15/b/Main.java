package com.kh.day15.b;

public class Main {
  public static void main(String[] args) {
    B b = new B();
    b.abc();
  }
}
