package com.kh.day15.i;

import com.kh.day14.ex4.E;

public class ScoreException extends Exception {
  public ScoreException(){
  }
  ScoreException(String s){
    super(s);
  }
}
