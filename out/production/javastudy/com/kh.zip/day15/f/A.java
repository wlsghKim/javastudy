package com.kh.day15.f;

public class A {
}
