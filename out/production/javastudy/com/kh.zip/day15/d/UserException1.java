package com.kh.day15.d;

public class UserException1 extends Exception {
  public UserException1(String message) {
    super(message);
  }
}
