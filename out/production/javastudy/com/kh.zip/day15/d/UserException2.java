package com.kh.day15.d;

public class UserException2 extends Exception {  //일반 예외


  public UserException2(String message) {
    super(message);

}
}
