package com.kh.day15.e;

public class UserException2 extends  RuntimeException {
  public UserException2(String msg) {
    super(msg);
  }
}
