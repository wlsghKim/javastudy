package com.kh.day15.e;

public class UserException1 extends RuntimeException {
  public UserException1(String msg){
    super(msg);
  }
}
