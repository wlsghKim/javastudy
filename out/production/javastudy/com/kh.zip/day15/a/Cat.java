package com.kh.day15.a;

public class Cat implements Soundable {
  @Override
  public void sound() {
    System.out.println("야옹!");

  }
}
