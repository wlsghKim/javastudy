package com.kh.day15.a;

public interface Power {
  void on();
  void off();


  }
