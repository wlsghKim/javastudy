package com.kh.day15.a;

public interface Chargable {
  void chargee(); // 충전

}
