package com.kh.day15.a;

public interface Soundable {
  //상수
  int X = 10; //pubblic static final
  //추상메소드
  void sound(); //public abstract

  //디폴트 메소드
  //정적 메소드


}
