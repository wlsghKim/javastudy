package com.kh.day15.a;

public interface Voltage {
  int Volt = 100;
}
