package com.kh.day14.d;

public class HighStudent extends Student{
  @Override
  public void eat() {

  }

  @Override
  public void smile() {

  }

  @Override
  public void study() {

  }
}
