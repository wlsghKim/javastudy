package com.kh.day14.d;

abstract public class Person2 {
  void smile() {

  }
  void eat() {

  }

}
