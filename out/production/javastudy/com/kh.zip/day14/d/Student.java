package com.kh.day14.d;

abstract public class Student extends Person{
//  @Override
//  public void smile() {
//    System.out.println("웃다");
//  }
//
//  @Override
//  public void eat() {
//    System.out.println("먹다");
//  }
}
