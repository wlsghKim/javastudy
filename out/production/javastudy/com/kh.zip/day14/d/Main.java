package com.kh.day14.d;

public class Main {
  public static void main(String[] args) {
//    Person p1 = new Person();
//    Person p2 = new Student();
    Person p3 = new HighStudent();
  }
}