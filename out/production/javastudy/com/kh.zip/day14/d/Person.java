package com.kh.day14.d;

abstract  public class Person {
  abstract public void smile();

  abstract public void eat();

  abstract public void study();

}
