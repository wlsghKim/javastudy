package com.kh.day14.f;

public interface Voltage {
  int Volt = 100;
}
