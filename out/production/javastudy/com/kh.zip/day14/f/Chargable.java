package com.kh.day14.f;

public interface Chargable {
  void chargee(); // 충전

}
