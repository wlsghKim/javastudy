package com.kh.day14.f;

 public class Cat implements Soundable{
  @Override
  public void sound() {
    System.out.println("야옹!");

  }
}
