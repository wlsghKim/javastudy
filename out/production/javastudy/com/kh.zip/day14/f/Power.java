package com.kh.day14.f;

public interface Power {
  void on();
  void off();


  }
