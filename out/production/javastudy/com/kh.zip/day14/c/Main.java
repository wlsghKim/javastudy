package com.kh.day14.c;

public class Main {
  public static void main(String[] args) {
    // case1) 지역변수
    //    final  int x;
//    x = 10; // 초기화
//    x = 20; //잴할당 불가
  }
}
