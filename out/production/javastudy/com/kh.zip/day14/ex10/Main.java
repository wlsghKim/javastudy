package com.kh.day14.ex10;

public class Main {
  public static void main(String[] args) {
    B bb = new B(5);

  }
}
