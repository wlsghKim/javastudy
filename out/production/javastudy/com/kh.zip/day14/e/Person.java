package com.kh.day14.e;

abstract public class Person {
  abstract public void eat();
  public void smile() {
    System.out.println("웃다");
  }
}
