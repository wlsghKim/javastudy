package com.kh.day14.e;

public class Student extends Person{
  @Override
  public void eat() {
    System.out.println("먹다");
  }
}
