package com.kh.day14.ex6;

public class A {
  String name = "홍길동";
  void hello() {
    System.out.println("안녕하세요");

  }
}

