package com.kh.day14.ex6;

public class B extends A{
  String name = "홍길순";
//  @Override
//  void hello() {
//    System.out.println("반갑습니다");
//  }
}
