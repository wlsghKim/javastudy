package com.kh.day14.ex4;

public class E extends B{
}
