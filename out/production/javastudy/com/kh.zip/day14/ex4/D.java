package com.kh.day14.ex4;

public class D extends C{
}
