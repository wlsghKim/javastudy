package com.kh.day14.ex4;

public class B extends A{
}
