package com.kh.day14.ex9;

public class B extends A{
  public B(){
//    super(); //부모클래스의 디폴트 생성자 호출
    super(10);
  }
}
