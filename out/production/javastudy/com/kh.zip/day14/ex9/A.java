package com.kh.day14.ex9;

public class A {
//  public A() {
//    super();
//  }
  A(int a) {
    System.out.println("A생성자");
  }
}
