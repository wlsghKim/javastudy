package com.kh.day12.zz;

public class A {
  int abc(int m) {
    m = 8;
    return m;
  }
    void bcd(int[] n){
      n[0] =4; n[1] = 5; n[2] =6;

    }
  }

